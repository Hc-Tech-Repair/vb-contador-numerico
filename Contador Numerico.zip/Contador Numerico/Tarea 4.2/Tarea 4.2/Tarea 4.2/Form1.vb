﻿Public Class Form1

    'Creamos la funcion para limpiar el ListBox'
    Private Sub LimpiarListBox()
        ListBox1.Items.Clear()
    End Sub

    'Creamos Funcion para añadir numeros al ListBox'
    Private Sub AddValues(ByVal arrayList As Integer())
        'Creamos Loop para añadir valores al ListBox'
        For Each intValue As Integer In arrayList
            ListBox1.Items.Add(intValue)
        Next
    End Sub

    Private Sub CalcularBtn_Click(sender As Object, e As EventArgs) Handles CalcularBtn.Click
        'Declaramos las Variables'
        Dim i As Integer
        Dim Repeticiones As Integer
        Dim Incremental As Integer
        Dim Indice As Integer

        Indice = RepeticionesTxt.Text - 1
        'Declaramos el Array'
        Dim Valores(Indice) As Integer

        'Limpiando Pantalla'
        LimpiarListBox()

        Repeticiones = RepeticionesTxt.Text - 1
        Incremental = Val(ValorInicialTxt.Text)

        'Creamos la repetidora que almacena los valores en el Array'
        For i = 0 To Repeticiones
            Valores(i) = Incremental
            Incremental = Incremental + Val(IncremetalTxt.Text)
        Next i

        'Llamamos la funcion para mostrar los valores en pantalla'
        AddValues(Valores)



    End Sub



End Class
